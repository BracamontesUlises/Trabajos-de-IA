namespace AI_Practica_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_perceptron_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            dataGridView1.Columns.Clear();

            switch (cb_problemas.Text)
            {
                case "AND":
                    int[] Yesp = new int[] { -1, -1, -1, 1 };

                    for (int i = 1; i <= 2; i++)
                    {
                        dataGridView1.Columns.Add("x" + i, "x" + i);
                    }
                    dataGridView1.Columns.Add("Yesp", "Yesp");
                    dataGridView1.Columns.Add("Ycal", "Ycal");
                    for (int i = 0; i < 4; i++)
                    {
                        string binary = Convert.ToString(i, 2).PadLeft(2, '0');
                        dataGridView1.Rows.Add(binary.Select(c => c.ToString()).ToArray());
                    }
                    for (int i = 0; i < Yesp.Length; i++)
                    {
                        dataGridView1.Rows[i].Cells[2].Value = Yesp[i];
                    }
                    break;
                case "OR":
                    int[] Yesp2 = new int[] { -1, 1, 1, 1 };

                    for (int i = 1; i <= 2; i++)
                    {
                        dataGridView1.Columns.Add("x" + i, "x" + i);
                    }
                    dataGridView1.Columns.Add("Yesp", "Yesp");
                    dataGridView1.Columns.Add("Ycal", "Ycal");
                    for (int i = 0; i < 4; i++)
                    {
                        string binary = Convert.ToString(i, 2).PadLeft(2, '0');
                        dataGridView1.Rows.Add(binary.Select(c => c.ToString()).ToArray());
                    }
                    for (int i = 0; i < Yesp2.Length; i++)
                    {
                        dataGridView1.Rows[i].Cells[2].Value = Yesp2[i];
                    }
                    break;
                case "XOR":
                    int[] Yesp3 = new int[] { -1, 1, 1, -1 };

                    for (int i = 1; i <= 2; i++)
                    {
                        dataGridView1.Columns.Add("x" + i, "x" + i);
                    }
                    dataGridView1.Columns.Add("Yesp", "Yesp");
                    dataGridView1.Columns.Add("Ycal", "Ycal");
                    for (int i = 0; i < 4; i++)
                    {
                        string binary = Convert.ToString(i, 2).PadLeft(2, '0');
                        dataGridView1.Rows.Add(binary.Select(c => c.ToString()).ToArray());
                    }
                    for (int i = 0; i < Yesp3.Length; i++)
                    {
                        dataGridView1.Rows[i].Cells[2].Value = Yesp3[i];
                    }
                    break;
                case "Mayoria Simple":
                    int[] Yesp4 = new int[] { -1, -1, -1, 1, -1, 1, 1, 1 };

                    for (int i = 1; i <= 3; i++)
                    {
                        dataGridView1.Columns.Add("x" + i, "x" + i);
                    }
                    dataGridView1.Columns.Add("Yesp", "Yesp");
                    dataGridView1.Columns.Add("Ycal", "Ycal");
                    for (int i = 0; i < 8; i++)
                    {
                        string binary = Convert.ToString(i, 2).PadLeft(3, '0');
                        dataGridView1.Rows.Add(binary.Select(c => c.ToString()).ToArray());
                    }
                    for (int i = 0; i < Yesp4.Length; i++)
                    {
                        dataGridView1.Rows[i].Cells[3].Value = Yesp4[i];
                    }
                    break;
                case "Paridad":
                    int[] Yesp5 = new int[] { -1, 1, -1, -1, 1, -1, 1, 1, 1, -1, 1, 1, -1, 1, -1, -1 };

                    for (int i = 1; i <= 4; i++)
                    {
                        dataGridView1.Columns.Add("x" + i, "x" + i);
                    }
                    dataGridView1.Columns.Add("Yesp", "Yesp");
                    dataGridView1.Columns.Add("Ycal", "Ycal");
                    for (int i = 0; i < 16; i++)
                    {
                        string binary = Convert.ToString(i, 2).PadLeft(4, '0');
                        dataGridView1.Rows.Add(binary.Select(c => c.ToString()).ToArray());
                    }
                    for (int i = 0; i < Yesp5.Length; i++)
                    {
                        dataGridView1.Rows[i].Cells[4].Value = Yesp5[i];
                    }
                    break;
                case "Problema":
                    int[] Yesp6 = new int[] { 1, -1, 1, -1, 1, -1 };
                    int[] X1 = new int[] { 2, 0, 2, 0, 1, 1 };
                    int[] X2 = new int[] { 0, 0, 2, 1, 1, 2 };

                    for (int i = 1; i <= 2; i++)
                    {
                        dataGridView1.Columns.Add("x" + i, "x" + i);
                    }
                    dataGridView1.Columns.Add("Yesp", "Yesp");
                    dataGridView1.Columns.Add("Ycal", "Ycal");
                    while (dataGridView1.Rows.Count < X1.Length)
                    {
                        dataGridView1.Rows.Add();
                        //dataGridView1.Rows.Add(X2[i]);
                    }
                    for (int i = 0; i < Yesp6.Length; i++)
                    {
                        dataGridView1.Rows[i].Cells[0].Value = X1[i];
                        dataGridView1.Rows[i].Cells[1].Value = X2[i];
                        dataGridView1.Rows[i].Cells[2].Value = Yesp6[i];
                    }
                    break;
            }
        }

        private void cb_problemas_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn_calcular_Click(object sender, EventArgs e)
        {
            switch (cb_problemas.Text)
            {
                case "AND":
                    Random rand = new Random();
                    float x1, x2, y1, y2, delw, delw1, delw2, delx, Ycal, Yesp;
                    float w1 = (float)Math.Round(rand.NextDouble(), 2);
                    float w2 = (float)Math.Round(rand.NextDouble(), 2);
                    float umb = (float)Math.Round(rand.NextDouble(), 2);
                    lbx_Epocas_y_Pesos.Items.Add("W1 = " + w1);
                    lbx_Epocas_y_Pesos.Items.Add("W2 = " + w2);
                    lbx_Epocas_y_Pesos.Items.Add("Umbral = " + umb);

                    int epoca = 1, iter = 1;
                    bool validacion = false;

                    while (!validacion)
                    {
                        lbx_Epocas_y_Pesos.Items.Add("Epoca = " + epoca);
                        lbx_Epocas_y_Pesos.Items.Add("\n");

                        validacion = true;

                        for (int i = 0; i < 4; i++)
                        {
                            DataGridViewRow row = dataGridView1.Rows[i];
                            x1 = Convert.ToSingle(row.Cells["x1"].Value);
                            x2 = Convert.ToSingle(row.Cells["x2"].Value);
                            Yesp = Convert.ToSingle(row.Cells["Yesp"].Value);

                            Ycal = (x1 * w1) + (x2 * w2) + umb;

                            if (Ycal > 0)
                            {
                                Ycal = 1;
                            }
                            else
                            {
                                Ycal = -1;
                            }

                            row.Cells["Ycal"].Value = Ycal;

                            lbx_Epocas_y_Pesos.Items.Add("Cambios en los pesos (" + i + ")");
                            lbx_Epocas_y_Pesos.Items.Add("W1 = " + w1);
                            lbx_Epocas_y_Pesos.Items.Add("W2 = " + w2);
                            lbx_Epocas_y_Pesos.Items.Add("Umbral = " + umb);
                            lbx_Epocas_y_Pesos.Items.Add("Ycal = " + Ycal);

                            if (Ycal != Yesp)
                            {
                                validacion = false;

                                delx = Yesp - Ycal;
                                delw1 = delx * x1;
                                delw2 = delx * x2;
                                delw = delx;

                                w1 += delw1;
                                w2 += delw2;
                                umb += delw;

                                lbx_Epocas_y_Pesos.Items.Add("Actualizacion (" + i + ")");
                                lbx_Epocas_y_Pesos.Items.Add("DX = " + delx);
                                lbx_Epocas_y_Pesos.Items.Add("DW1 = " + delw1);
                                lbx_Epocas_y_Pesos.Items.Add("DW2 = " + delw2);
                                lbx_Epocas_y_Pesos.Items.Add("DW0 = " + delw);
                                lbx_Epocas_y_Pesos.Items.Add("\n");
                                lbx_Epocas_y_Pesos.Items.Add("Nuevos datos");
                                lbx_Epocas_y_Pesos.Items.Add("W1 = " + w1);
                                lbx_Epocas_y_Pesos.Items.Add("W2 = " + w2);
                                lbx_Epocas_y_Pesos.Items.Add("Umbral = " + umb);
                                lbx_Epocas_y_Pesos.Items.Add("\n");
                            }
                        }

                        epoca++;
                    }

                    lbx_Epocas_y_Pesos.Items.Add("Total de epocas necesarias = " + epoca);

                    break;
                case "OR":
                    Random randOR = new Random();
                    float x1OR, x2OR, y1OR, y2OR, delwOR, delw1OR, delw2OR, delxOR, YcalOR, YespOR;
                    float w1OR = (float)Math.Round(randOR.NextDouble(), 2);
                    float w2OR = (float)Math.Round(randOR.NextDouble(), 2);
                    float umbOR = (float)Math.Round(randOR.NextDouble(), 2);
                    lbx_Epocas_y_Pesos.Items.Add("W1 = " + w1OR);
                    lbx_Epocas_y_Pesos.Items.Add("W2 = " + w2OR);
                    lbx_Epocas_y_Pesos.Items.Add("Umbral = " + umbOR);

                    int epocaOR = 1, iterOR = 1;
                    bool validacionOR = false;

                    while (!validacionOR)
                    {
                        lbx_Epocas_y_Pesos.Items.Add("Epoca = " + epocaOR);
                        lbx_Epocas_y_Pesos.Items.Add("\n");

                        validacionOR = true;

                        for (int i = 0; i < 4; i++)
                        {
                            DataGridViewRow row = dataGridView1.Rows[i];
                            x1OR = Convert.ToSingle(row.Cells["x1"].Value);
                            x2OR = Convert.ToSingle(row.Cells["x2"].Value);
                            YespOR = Convert.ToSingle(row.Cells["Yesp"].Value);

                            YcalOR = (x1OR * w1OR) + (x2OR * w2OR) + umbOR;

                            if (YcalOR > 0)
                            {
                                YcalOR = 1;
                            }
                            else
                            {
                                YcalOR = -1;
                            }

                            row.Cells["Ycal"].Value = YcalOR;

                            lbx_Epocas_y_Pesos.Items.Add("Cambios en los pesos (" + i + ")");
                            lbx_Epocas_y_Pesos.Items.Add("W1 = " + w1OR);
                            lbx_Epocas_y_Pesos.Items.Add("W2 = " + w2OR);
                            lbx_Epocas_y_Pesos.Items.Add("Umbral = " + umbOR);
                            lbx_Epocas_y_Pesos.Items.Add("Ycal = " + YcalOR);

                            if (YcalOR != YespOR)
                            {
                                validacion = false;

                                delxOR = YespOR - YcalOR;
                                delw1OR = delxOR * x1OR;
                                delw2OR = delxOR * x2OR;
                                delwOR = delxOR;

                                w1OR += delw1OR;
                                w2OR += delw2OR;
                                umbOR += delwOR;

                                lbx_Epocas_y_Pesos.Items.Add("Actualizacion (" + i + ")");
                                lbx_Epocas_y_Pesos.Items.Add("DX = " + delxOR);
                                lbx_Epocas_y_Pesos.Items.Add("DW1 = " + delw1OR);
                                lbx_Epocas_y_Pesos.Items.Add("DW2 = " + delw2OR);
                                lbx_Epocas_y_Pesos.Items.Add("DW0 = " + delwOR);
                                lbx_Epocas_y_Pesos.Items.Add("\n");
                                lbx_Epocas_y_Pesos.Items.Add("Nuevos datos");
                                lbx_Epocas_y_Pesos.Items.Add("W1 = " + w1OR);
                                lbx_Epocas_y_Pesos.Items.Add("W2 = " + w2OR);
                                lbx_Epocas_y_Pesos.Items.Add("Umbral = " + umbOR);
                                lbx_Epocas_y_Pesos.Items.Add("\n");
                            }
                        }

                        epocaOR++;
                    }

                    lbx_Epocas_y_Pesos.Items.Add("Total de epocas necesarias = " + epocaOR);
                    break;
                case "XOR":
                    Random randXOR = new Random();
                    float x1XOR, x2XOR, y1XOR, y2XOR, delwXOR, delw1XOR, delw2XOR, delxXOR, YcalXOR, YespXOR;
                    float w1XOR = (float)Math.Round(randXOR.NextDouble(), 2);
                    float w2XOR = (float)Math.Round(randXOR.NextDouble(), 2);
                    float umbXOR = (float)Math.Round(randXOR.NextDouble(), 2);
                    lbx_Epocas_y_Pesos.Items.Add("W1 = " + w1XOR);
                    lbx_Epocas_y_Pesos.Items.Add("W2 = " + w2XOR);
                    lbx_Epocas_y_Pesos.Items.Add("Umbral = " + umbXOR);

                    int maxEpoca = 100, epocaXOR = 1;
                    bool validacionXOR = false;

                    while (epocaXOR < maxEpoca)
                    {
                        validacionXOR = true;

                        for (int i = 0; i < 4; i++)
                        {
                            DataGridViewRow row = dataGridView1.Rows[i];
                            x1XOR = Convert.ToSingle(row.Cells["x1"].Value);
                            x2XOR = Convert.ToSingle(row.Cells["x2"].Value);
                            YespXOR = Convert.ToSingle(row.Cells["Yesp"].Value);

                            YcalXOR = (x1XOR * w1XOR) + (x2XOR * w2XOR) + umbXOR;

                            if (YcalXOR > 0)
                            {
                                YcalXOR = 1;
                            }
                            else
                            {
                                YcalXOR = -1;
                            }

                            row.Cells["Ycal"].Value = YcalXOR;

                            lbx_Epocas_y_Pesos.Items.Add("Cambios en los pesos (" + i + ")");
                            lbx_Epocas_y_Pesos.Items.Add("W1 = " + w1XOR);
                            lbx_Epocas_y_Pesos.Items.Add("W2 = " + w2XOR);
                            lbx_Epocas_y_Pesos.Items.Add("Umbral = " + umbXOR);
                            lbx_Epocas_y_Pesos.Items.Add("Ycal = " + YcalXOR);

                            if (YcalXOR != YespXOR)
                            {
                                validacionXOR = false;

                                delxXOR = YespXOR - YcalXOR;
                                delw1XOR = delxXOR * x1XOR;
                                delw2XOR = delxXOR * x2XOR;
                                delwXOR = delxXOR;

                                w1XOR += delw1XOR;
                                w2XOR += delw2XOR;
                                umbXOR += delwXOR;

                                lbx_Epocas_y_Pesos.Items.Add("Actualizacion (" + i + ")");
                                lbx_Epocas_y_Pesos.Items.Add("DX = " + delxXOR);
                                lbx_Epocas_y_Pesos.Items.Add("DW1 = " + delw1XOR);
                                lbx_Epocas_y_Pesos.Items.Add("DW2 = " + delw2XOR);
                                lbx_Epocas_y_Pesos.Items.Add("DW0 = " + delwXOR);
                                lbx_Epocas_y_Pesos.Items.Add("\n");
                                lbx_Epocas_y_Pesos.Items.Add("Nuevos datos");
                                lbx_Epocas_y_Pesos.Items.Add("W1 = " + w1XOR);
                                lbx_Epocas_y_Pesos.Items.Add("W2 = " + w2XOR);
                                lbx_Epocas_y_Pesos.Items.Add("Umbral = " + umbXOR);
                                lbx_Epocas_y_Pesos.Items.Add("\n");
                            }
                        }

                        epocaXOR++;
                    }
                    lbx_Epocas_y_Pesos.Items.Add("Total de epocas necesarias = " + epocaXOR);
                    if (!validacionXOR)
                    {
                        lbx_Epocas_y_Pesos.Items.Add("No se encontro una solucion dentro de 100 epocas");
                    }
                    break;
                case "Mayoria Simple":
                    Random randMS = new Random();
                    float x1MS, x2MS, x3MS, y1MS, y2MS, y3MS, delwMS, delw1MS, delw2MS, delw3MS, delxMS, YcalMS, YespMS;
                    float w1MS = (float)Math.Round(randMS.NextDouble(), 2);
                    float w2MS = (float)Math.Round(randMS.NextDouble(), 2);
                    float w3MS = (float)Math.Round(randMS.NextDouble(), 2);
                    float umbMS = (float)Math.Round(randMS.NextDouble(), 2);
                    lbx_Epocas_y_Pesos.Items.Add("W1 = " + w1MS);
                    lbx_Epocas_y_Pesos.Items.Add("W2 = " + w2MS);
                    lbx_Epocas_y_Pesos.Items.Add("W3 = " + w3MS);
                    lbx_Epocas_y_Pesos.Items.Add("Umbral = " + umbMS);

                    int epocaMS = 0, maxepocaMS = 100;
                    bool validacionMS = false;

                    while (epocaMS < maxepocaMS)
                    {
                        lbx_Epocas_y_Pesos.Items.Add("Epoca = " + epocaMS);
                        lbx_Epocas_y_Pesos.Items.Add("\n");

                        validacionXOR = true;

                        for (int i = 0; i < 8; i++)
                        {
                            DataGridViewRow row = dataGridView1.Rows[i];
                            x1MS = Convert.ToSingle(row.Cells["x1"].Value);
                            x2MS = Convert.ToSingle(row.Cells["x2"].Value);
                            x3MS = Convert.ToSingle(row.Cells["x3"].Value);
                            YespMS = Convert.ToSingle(row.Cells["Yesp"].Value);

                            YcalMS = (x1MS * w1MS) + (x2MS * w2MS) + (x3MS * w3MS) + umbMS;

                            if (YcalMS > 0)
                            {
                                YcalMS = 1;
                            }
                            else
                            {
                                YcalMS = -1;
                            }

                            row.Cells["Ycal"].Value = YcalMS;

                            lbx_Epocas_y_Pesos.Items.Add("Cambios en los pesos (" + i + ")");
                            lbx_Epocas_y_Pesos.Items.Add("W1 = " + w1MS);
                            lbx_Epocas_y_Pesos.Items.Add("W2 = " + w2MS);
                            lbx_Epocas_y_Pesos.Items.Add("W3 = " + w3MS);
                            lbx_Epocas_y_Pesos.Items.Add("Umbral = " + umbMS);
                            lbx_Epocas_y_Pesos.Items.Add("Ycal = " + YcalMS);

                            if (YcalMS != YespMS)
                            {
                                validacionMS = false;

                                delxMS = YespMS - YcalMS;
                                delw1MS = delxMS * x1MS;
                                delw2MS = delxMS * x2MS;
                                delw3MS = delxMS * x3MS;
                                delwMS = delxMS;

                                w1MS += delw1MS;
                                w2MS += delw2MS;
                                w3MS += delw3MS;
                                umbMS += delwMS;

                                lbx_Epocas_y_Pesos.Items.Add("Actualizacion (" + i + ")");
                                lbx_Epocas_y_Pesos.Items.Add("DX = " + delxMS);
                                lbx_Epocas_y_Pesos.Items.Add("DW1 = " + delw1MS);
                                lbx_Epocas_y_Pesos.Items.Add("DW2 = " + delw2MS);
                                lbx_Epocas_y_Pesos.Items.Add("DW3 = " + delw3MS);
                                lbx_Epocas_y_Pesos.Items.Add("DW0 = " + delwMS);
                                lbx_Epocas_y_Pesos.Items.Add("\n");
                                lbx_Epocas_y_Pesos.Items.Add("Nuevos datos");
                                lbx_Epocas_y_Pesos.Items.Add("W1 = " + w1MS);
                                lbx_Epocas_y_Pesos.Items.Add("W2 = " + w2MS);
                                lbx_Epocas_y_Pesos.Items.Add("W3 = " + w3MS);
                                lbx_Epocas_y_Pesos.Items.Add("Umbral = " + umbMS);
                                lbx_Epocas_y_Pesos.Items.Add("\n");
                            }
                        }

                        epocaMS++;
                    }
                    lbx_Epocas_y_Pesos.Items.Add("Total de epocas necesarias = " + epocaMS);
                    if (!validacionMS)
                    {
                        lbx_Epocas_y_Pesos.Items.Add("No se encontro una solucion dentro de 100 epocas");
                    }

                    break;
                case "Paridad":
                    Random randPx = new Random();
                    float x1Px, x2Px, x3Px, x4Px, y1Px, y2Px, y3Px, y4Px, delwPx, delw1Px, delw2Px, delw3Px, delw4Px, delxPx, YcalPx, YespPx;
                    float w1Px = (float)Math.Round(randPx.NextDouble(), 2);
                    float w2Px = (float)Math.Round(randPx.NextDouble(), 2);
                    float w3Px = (float)Math.Round(randPx.NextDouble(), 2);
                    float w4Px = (float)Math.Round(randPx.NextDouble(), 2);
                    float umbPx = (float)Math.Round(randPx.NextDouble(), 2);
                    lbx_Epocas_y_Pesos.Items.Add("W1 = " + w1Px);
                    lbx_Epocas_y_Pesos.Items.Add("W2 = " + w2Px);
                    lbx_Epocas_y_Pesos.Items.Add("W3 = " + w3Px);
                    lbx_Epocas_y_Pesos.Items.Add("W4 = " + w4Px);
                    lbx_Epocas_y_Pesos.Items.Add("Umbral = " + umbPx);

                    int epocaPx = 0, maxepocaPx = 100;
                    bool validacionPx = false;

                    while (epocaPx < maxepocaPx)
                    {
                        lbx_Epocas_y_Pesos.Items.Add("Epoca = " + epocaPx);
                        lbx_Epocas_y_Pesos.Items.Add("\n");

                        validacionXOR = true;

                        for (int i = 0; i < 16; i++)
                        {
                            DataGridViewRow row = dataGridView1.Rows[i];
                            x1Px = Convert.ToSingle(row.Cells["x1"].Value);
                            x2Px = Convert.ToSingle(row.Cells["x2"].Value);
                            x3Px = Convert.ToSingle(row.Cells["x3"].Value);
                            x4Px = Convert.ToSingle(row.Cells["x4"].Value);
                            YespPx = Convert.ToSingle(row.Cells["Yesp"].Value);

                            YcalPx = (x1Px * w1Px) + (x2Px * w2Px) + (x3Px * w3Px) + (x4Px * w4Px) + umbPx;

                            if (YcalPx > 0)
                            {
                                YcalPx = 1;
                            }
                            else
                            {
                                YcalPx = -1;
                            }

                            row.Cells["Ycal"].Value = YcalPx;

                            lbx_Epocas_y_Pesos.Items.Add("Cambios en los pesos (" + i + ")");
                            lbx_Epocas_y_Pesos.Items.Add("W1 = " + w1Px);
                            lbx_Epocas_y_Pesos.Items.Add("W2 = " + w2Px);
                            lbx_Epocas_y_Pesos.Items.Add("W3 = " + w3Px);
                            lbx_Epocas_y_Pesos.Items.Add("W4 = " + w4Px);
                            lbx_Epocas_y_Pesos.Items.Add("Umbral = " + umbPx);
                            lbx_Epocas_y_Pesos.Items.Add("Ycal = " + YcalPx);

                            if (YcalPx != YespPx)
                            {
                                validacionPx = false;

                                delxPx = YespPx - YcalPx;
                                delw1Px = delxPx * x1Px;
                                delw2Px = delxPx * x2Px;
                                delw3Px = delxPx * x3Px;
                                delw4Px = delxPx * x4Px;
                                delwPx = delxPx;

                                w1Px += delw1Px;
                                w2Px += delw2Px;
                                w3Px += delw3Px;
                                w4Px += delw4Px;
                                umbPx += delwPx;

                                lbx_Epocas_y_Pesos.Items.Add("Actualizacion (" + i + ")");
                                lbx_Epocas_y_Pesos.Items.Add("DX = " + delxPx);
                                lbx_Epocas_y_Pesos.Items.Add("DW1 = " + delw1Px);
                                lbx_Epocas_y_Pesos.Items.Add("DW2 = " + delw2Px);
                                lbx_Epocas_y_Pesos.Items.Add("DW3 = " + delw3Px);
                                lbx_Epocas_y_Pesos.Items.Add("DW4 = " + delw4Px);
                                lbx_Epocas_y_Pesos.Items.Add("DW0 = " + delwPx);
                                lbx_Epocas_y_Pesos.Items.Add("\n");
                                lbx_Epocas_y_Pesos.Items.Add("Nuevos datos");
                                lbx_Epocas_y_Pesos.Items.Add("W1 = " + w1Px);
                                lbx_Epocas_y_Pesos.Items.Add("W2 = " + w2Px);
                                lbx_Epocas_y_Pesos.Items.Add("W3 = " + w3Px);
                                lbx_Epocas_y_Pesos.Items.Add("W4 = " + w4Px);
                                lbx_Epocas_y_Pesos.Items.Add("Umbral = " + umbPx);
                                lbx_Epocas_y_Pesos.Items.Add("\n");
                            }
                        }

                        epocaPx++;
                    }
                    lbx_Epocas_y_Pesos.Items.Add("Total de epocas necesarias = " + epocaPx);
                    if (!validacionPx)
                    {
                        lbx_Epocas_y_Pesos.Items.Add("No se encontro una solucion dentro de 100 epocas");
                    }

                    break;
                case "Problema":
                    Random randP = new Random();
                    float x1P, x2P, y1P, y2P, delwP, delw1P, delw2P, delxP, YcalP, YespP;
                    float w1P = (float)Math.Round(randP.NextDouble(), 2);
                    float w2P = (float)Math.Round(randP.NextDouble(), 2);
                    float umbP = (float)Math.Round(randP.NextDouble(), 2);
                    lbx_Epocas_y_Pesos.Items.Add("W1 = " + w1P);
                    lbx_Epocas_y_Pesos.Items.Add("W2 = " + w2P);
                    lbx_Epocas_y_Pesos.Items.Add("Umbral = " + umbP);

                    int epocaP = 1, iterP = 1;
                    bool validacionP = false;

                    while (!validacionP)
                    {
                        lbx_Epocas_y_Pesos.Items.Add("Epoca = " + epocaP);
                        lbx_Epocas_y_Pesos.Items.Add("\n");

                        validacionP = true;

                        for (int i = 0; i < 6; i++)
                        {
                            DataGridViewRow row = dataGridView1.Rows[i];
                            x1P = Convert.ToSingle(row.Cells["x1"].Value);
                            x2P = Convert.ToSingle(row.Cells["x2"].Value);
                            YespP = Convert.ToSingle(row.Cells["Yesp"].Value);

                            YcalP = (x1P * w1P) + (x2P * w2P) + umbP;

                            if (YcalP > 0)
                            {
                                YcalP = 1;
                            }
                            else
                            {
                                YcalP = -1;
                            }

                            row.Cells["Ycal"].Value = YcalP;

                            lbx_Epocas_y_Pesos.Items.Add("Cambios en los pesos (" + i + ")");
                            lbx_Epocas_y_Pesos.Items.Add("W1 = " + w1P);
                            lbx_Epocas_y_Pesos.Items.Add("W2 = " + w2P);
                            lbx_Epocas_y_Pesos.Items.Add("Umbral = " + umbP);
                            lbx_Epocas_y_Pesos.Items.Add("Ycal = " + YcalP);

                            if (YcalP != YespP)
                            {
                                validacionP = false;

                                delxP = YespP - YcalP;
                                delw1P = delxP * x1P;
                                delw2P = delxP * x2P;
                                delwP = delxP;

                                w1P += delw1P;
                                w2P += delw2P;
                                umbP += delwP;

                                lbx_Epocas_y_Pesos.Items.Add("Actualizacion (" + i + ")");
                                lbx_Epocas_y_Pesos.Items.Add("DX = " + delxP);
                                lbx_Epocas_y_Pesos.Items.Add("DW1 = " + delw1P);
                                lbx_Epocas_y_Pesos.Items.Add("DW2 = " + delw2P);
                                lbx_Epocas_y_Pesos.Items.Add("DW0 = " + delwP);
                                lbx_Epocas_y_Pesos.Items.Add("\n");
                                lbx_Epocas_y_Pesos.Items.Add("Nuevos datos");
                                lbx_Epocas_y_Pesos.Items.Add("W1 = " + w1P);
                                lbx_Epocas_y_Pesos.Items.Add("W2 = " + w2P);
                                lbx_Epocas_y_Pesos.Items.Add("Umbral = " + umbP);
                                lbx_Epocas_y_Pesos.Items.Add("\n");
                            }
                        }

                        epocaP++;
                    }

                    lbx_Epocas_y_Pesos.Items.Add("Total de epocas necesarias = " + epocaP);
                    break;
            }
        }

        private void btn_limpiar_Click(object sender, EventArgs e)
        {
            dataGridView1.Columns.Clear();
            dataGridView1.Rows.Clear();
            lbx_Epocas_y_Pesos.Items.Clear();
        }
    }
}