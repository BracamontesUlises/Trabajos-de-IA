﻿namespace AI_Practica_4
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lbl_problema = new Label();
            btn_perceptron = new Button();
            cb_problemas = new ComboBox();
            dataGridView1 = new DataGridView();
            lbx_Epocas_y_Pesos = new ListBox();
            btn_calcular = new Button();
            btn_limpiar = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // lbl_problema
            // 
            lbl_problema.AutoSize = true;
            lbl_problema.Location = new Point(35, 58);
            lbl_problema.Name = "lbl_problema";
            lbl_problema.Size = new Size(58, 15);
            lbl_problema.TabIndex = 0;
            lbl_problema.Text = "Problema";
            // 
            // btn_perceptron
            // 
            btn_perceptron.Location = new Point(243, 86);
            btn_perceptron.Name = "btn_perceptron";
            btn_perceptron.Size = new Size(84, 48);
            btn_perceptron.TabIndex = 2;
            btn_perceptron.Text = "Perceptron";
            btn_perceptron.UseVisualStyleBackColor = true;
            btn_perceptron.Click += btn_perceptron_Click;
            // 
            // cb_problemas
            // 
            cb_problemas.FormattingEnabled = true;
            cb_problemas.Items.AddRange(new object[] { "AND", "OR", "XOR", "Mayoria Simple", "Paridad", "Problema" });
            cb_problemas.Location = new Point(35, 86);
            cb_problemas.Name = "cb_problemas";
            cb_problemas.Size = new Size(179, 23);
            cb_problemas.TabIndex = 3;
            cb_problemas.SelectedIndexChanged += cb_problemas_SelectedIndexChanged;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(35, 174);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(396, 224);
            dataGridView1.TabIndex = 4;
            // 
            // lbx_Epocas_y_Pesos
            // 
            lbx_Epocas_y_Pesos.FormattingEnabled = true;
            lbx_Epocas_y_Pesos.ItemHeight = 15;
            lbx_Epocas_y_Pesos.Location = new Point(478, 49);
            lbx_Epocas_y_Pesos.Name = "lbx_Epocas_y_Pesos";
            lbx_Epocas_y_Pesos.Size = new Size(203, 349);
            lbx_Epocas_y_Pesos.TabIndex = 5;
            // 
            // btn_calcular
            // 
            btn_calcular.Location = new Point(342, 86);
            btn_calcular.Name = "btn_calcular";
            btn_calcular.Size = new Size(89, 48);
            btn_calcular.TabIndex = 6;
            btn_calcular.Text = "Calcular";
            btn_calcular.UseVisualStyleBackColor = true;
            btn_calcular.Click += btn_calcular_Click;
            // 
            // btn_limpiar
            // 
            btn_limpiar.Location = new Point(700, 392);
            btn_limpiar.Name = "btn_limpiar";
            btn_limpiar.Size = new Size(88, 46);
            btn_limpiar.TabIndex = 7;
            btn_limpiar.Text = "Limpiar";
            btn_limpiar.UseVisualStyleBackColor = true;
            btn_limpiar.Click += btn_limpiar_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btn_limpiar);
            Controls.Add(btn_calcular);
            Controls.Add(lbx_Epocas_y_Pesos);
            Controls.Add(dataGridView1);
            Controls.Add(cb_problemas);
            Controls.Add(btn_perceptron);
            Controls.Add(lbl_problema);
            Name = "Form1";
            Text = "btn";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbl_problema;
        private Button btn_perceptron;
        private ComboBox cb_problemas;
        private DataGridView dataGridView1;
        private ListBox lbx_Epocas_y_Pesos;
        private Button btn_calcular;
        private Button btn_limpiar;
    }
}