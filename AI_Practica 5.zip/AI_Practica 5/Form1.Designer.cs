﻿namespace AI_Practica_5
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn_leer = new Button();
            btn_perceptron = new Button();
            cb_clases = new ComboBox();
            lb_datos_iris = new ListBox();
            lb_epocas = new ListBox();
            dataGridView1 = new DataGridView();
            btn_calcular = new Button();
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // btn_leer
            // 
            btn_leer.Location = new Point(12, 52);
            btn_leer.Name = "btn_leer";
            btn_leer.Size = new Size(89, 51);
            btn_leer.TabIndex = 0;
            btn_leer.Text = "Leer Documento";
            btn_leer.UseVisualStyleBackColor = true;
            btn_leer.Click += btn_leer_Click;
            // 
            // btn_perceptron
            // 
            btn_perceptron.Location = new Point(12, 170);
            btn_perceptron.Name = "btn_perceptron";
            btn_perceptron.Size = new Size(89, 34);
            btn_perceptron.TabIndex = 1;
            btn_perceptron.Text = "Perceptron";
            btn_perceptron.UseVisualStyleBackColor = true;
            btn_perceptron.Click += btn_perceptron_Click;
            // 
            // cb_clases
            // 
            cb_clases.FormattingEnabled = true;
            cb_clases.Items.AddRange(new object[] { "Setosa-Versicolor", "Setosa-Virginica", "Versicolor-Virginica" });
            cb_clases.Location = new Point(12, 126);
            cb_clases.Name = "cb_clases";
            cb_clases.Size = new Size(121, 23);
            cb_clases.TabIndex = 2;
            // 
            // lb_datos_iris
            // 
            lb_datos_iris.FormattingEnabled = true;
            lb_datos_iris.ItemHeight = 15;
            lb_datos_iris.Location = new Point(151, 52);
            lb_datos_iris.Name = "lb_datos_iris";
            lb_datos_iris.Size = new Size(174, 379);
            lb_datos_iris.TabIndex = 3;
            // 
            // lb_epocas
            // 
            lb_epocas.FormattingEnabled = true;
            lb_epocas.ItemHeight = 15;
            lb_epocas.Location = new Point(341, 52);
            lb_epocas.Name = "lb_epocas";
            lb_epocas.Size = new Size(228, 379);
            lb_epocas.TabIndex = 4;
            lb_epocas.SelectedIndexChanged += lb_epocas_SelectedIndexChanged;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(587, 52);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(311, 379);
            dataGridView1.TabIndex = 5;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // btn_calcular
            // 
            btn_calcular.Location = new Point(12, 223);
            btn_calcular.Name = "btn_calcular";
            btn_calcular.Size = new Size(89, 34);
            btn_calcular.TabIndex = 6;
            btn_calcular.Text = "Calcular";
            btn_calcular.UseVisualStyleBackColor = true;
            btn_calcular.Click += btn_calcular_Click;
            // 
            // button1
            // 
            button1.Location = new Point(767, 453);
            button1.Name = "button1";
            button1.Size = new Size(91, 35);
            button1.TabIndex = 7;
            button1.Text = "Limpiar";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(910, 512);
            Controls.Add(button1);
            Controls.Add(btn_calcular);
            Controls.Add(dataGridView1);
            Controls.Add(lb_epocas);
            Controls.Add(lb_datos_iris);
            Controls.Add(cb_clases);
            Controls.Add(btn_perceptron);
            Controls.Add(btn_leer);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button btn_leer;
        private Button btn_perceptron;
        private ComboBox cb_clases;
        private ListBox lb_datos_iris;
        private ListBox lb_epocas;
        private DataGridView dataGridView1;
        private Button btn_calcular;
        private Button button1;
    }
}