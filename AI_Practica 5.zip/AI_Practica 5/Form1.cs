using System.IO;

namespace AI_Practica_5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_leer_Click(object sender, EventArgs e)
        {
            StreamReader lector;


            lector = File.OpenText("iris.data");

            while (!lector.EndOfStream)
            {
                lb_datos_iris.Items.Add(lector.ReadLine());
            }
        }

        private void btn_perceptron_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            dataGridView1.Columns.Clear();

            switch (cb_clases.Text)
            {
                case "Setosa-Versicolor":
                    dataGridView1.Columns.Add("LS", "LS");
                    dataGridView1.Columns.Add("AS", "AS");
                    dataGridView1.Columns.Add("LP", "LS");
                    dataGridView1.Columns.Add("AP", "LS");
                    dataGridView1.Columns.Add("Clase", "Clase");
                    dataGridView1.Columns.Add("Yesp", "Yesp");
                    dataGridView1.Columns.Add("Ycal", "Ycal");

                    string[] lineas = File.ReadAllLines("iris.data");

                    for (int i = 0; i < 50; i++)
                    {
                        string[] columnas = lineas[i].Split(',');
                        if (columnas.Length >= 4)
                        {
                            dataGridView1.Rows.Add(columnas[0], columnas[1], columnas[2], columnas[3]);
                            dataGridView1.Rows[i].Cells[4].Value = "Setosa";
                            dataGridView1.Rows[i].Cells[5].Value = -1;
                        }
                    }
                    for (int i = 50; i < 100; i++)
                    {
                        string[] columnas = lineas[i].Split(',');
                        if (columnas.Length >= 4)
                        {
                            dataGridView1.Rows.Add(columnas[0], columnas[1], columnas[2], columnas[3]);
                            dataGridView1.Rows[i].Cells[4].Value = "Versicolor";
                            dataGridView1.Rows[i].Cells[5].Value = 1;
                        }
                    }
                    break;
                case "Setosa-Virginica":
                    dataGridView1.Columns.Add("LS", "LS");
                    dataGridView1.Columns.Add("AS", "AS");
                    dataGridView1.Columns.Add("LP", "LS");
                    dataGridView1.Columns.Add("AP", "LS");
                    dataGridView1.Columns.Add("Clase", "Clase");
                    dataGridView1.Columns.Add("Yesp", "Yesp");
                    dataGridView1.Columns.Add("Ycal", "Ycal");

                    string[] lineas2 = File.ReadAllLines("iris.data");

                    for (int i = 0; i < 50; i++)
                    {
                        string[] columnas = lineas2[i].Split(',');
                        if (columnas.Length >= 4)
                        {
                            dataGridView1.Rows.Add(columnas[0], columnas[1], columnas[2], columnas[3]);
                            dataGridView1.Rows[i].Cells[4].Value = "Setosa";
                            dataGridView1.Rows[i].Cells[5].Value = -1;
                        }
                    }

                    for (int indice = 100; indice < 150; indice++)
                    {
                        for (int i = 50; i < 100; i++)
                        {
                            string[] columnas = lineas2[indice].Split(',');
                            if (columnas.Length >= 4)
                            {
                                dataGridView1.Rows.Add(columnas[0], columnas[1], columnas[2], columnas[3]);
                                dataGridView1.Rows[i].Cells[4].Value = "Virginica";
                                dataGridView1.Rows[i].Cells[5].Value = 1;
                                indice++;
                            }
                        }
                    }
                    break;
                case "Versicolor-Virginica":
                    dataGridView1.Columns.Add("LS", "LS");
                    dataGridView1.Columns.Add("AS", "AS");
                    dataGridView1.Columns.Add("LP", "LS");
                    dataGridView1.Columns.Add("AP", "LS");
                    dataGridView1.Columns.Add("Clase", "Clase");
                    dataGridView1.Columns.Add("Yesp", "Yesp");
                    dataGridView1.Columns.Add("Ycal", "Ycal");

                    string[] lineas3 = File.ReadAllLines("iris.data");

                    for (int i = 0; i < 1; i++)
                    {
                        for (int indice = 50; indice < 100; indice++)
                        {
                            string[] columnas = lineas3[indice].Split(',');
                            if (columnas.Length >= 4)
                            {
                                dataGridView1.Rows.Add(columnas[0], columnas[1], columnas[2], columnas[3]);
                            }
                        }
                    }
                    for (int i = 0; i < 50; i++)
                    {
                        dataGridView1.Rows[i].Cells[4].Value = "Versicolor";
                        dataGridView1.Rows[i].Cells[5].Value = -1;
                    }

                    for (int i = 50; i < 51; i++)
                    {
                        for (int indice = 100; indice < 150; indice++)
                        {
                            string[] columnas = lineas3[indice].Split(',');
                            if (columnas.Length >= 4)
                            {
                                dataGridView1.Rows.Add(columnas[0], columnas[1], columnas[2], columnas[3]);
                            }
                        }
                    }
                    for (int i = 50; i < 100; i++)
                    {
                        dataGridView1.Rows[i].Cells[4].Value = "Virginica";
                        dataGridView1.Rows[i].Cells[5].Value = 1;
                    }
                    break;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void lb_epocas_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn_calcular_Click(object sender, EventArgs e)
        {
            switch (cb_clases.Text)
            {
                case "Setosa-Versicolor":
                    Random rand = new Random();
                    float x1, x2, x3, x4, y1, y2, y3, y4, delw, delw1, delw2, delw3, delw4, delx, Ycal, Yesp;
                    float w1 = (float)Math.Round(rand.NextDouble(), 2);
                    float w2 = (float)Math.Round(rand.NextDouble(), 2);
                    float w3 = (float)Math.Round(rand.NextDouble(), 2);
                    float w4 = (float)Math.Round(rand.NextDouble(), 2);
                    float umb = (float)Math.Round(rand.NextDouble(), 2);
                    lb_epocas.Items.Add("W1 = " + w1);
                    lb_epocas.Items.Add("W2 = " + w2);
                    lb_epocas.Items.Add("W3 = " + w3);
                    lb_epocas.Items.Add("W4 = " + w4);
                    lb_epocas.Items.Add("Umbral = " + umb);

                    int epoca = 0, maxepoca = 5;
                    bool validacion = false;

                    while (epoca < maxepoca)
                    {
                        lb_epocas.Items.Add("Epoca = " + epoca);
                        lb_epocas.Items.Add("\n");

                        validacion = true;

                        for (int i = 0; i < 100; i++)
                        {
                            DataGridViewRow row = dataGridView1.Rows[i];
                            x1 = Convert.ToSingle(row.Cells["LS"].Value);
                            x2 = Convert.ToSingle(row.Cells["AS"].Value);
                            x3 = Convert.ToSingle(row.Cells["LP"].Value);
                            x4 = Convert.ToSingle(row.Cells["AP"].Value);
                            Yesp = Convert.ToSingle(row.Cells["Yesp"].Value);

                            Ycal = (x1 * w1) + (x2 * w2) + (x3 * w3) + (x4 * w4) + umb;

                            if (Ycal > 0)
                            {
                                Ycal = 1;
                            }
                            else
                            {
                                Ycal = -1;
                            }

                            row.Cells["Ycal"].Value = Ycal;

                            lb_epocas.Items.Add("Cambios en los pesos (" + i + ")");
                            lb_epocas.Items.Add("W1 = " + w1);
                            lb_epocas.Items.Add("W2 = " + w2);
                            lb_epocas.Items.Add("W3 = " + w3);
                            lb_epocas.Items.Add("W4 = " + w4);
                            lb_epocas.Items.Add("Umbral = " + umb);
                            lb_epocas.Items.Add("Ycal = " + Ycal);

                            if (Ycal != Yesp)
                            {
                                validacion = false;

                                delx = Yesp - Ycal;
                                delw1 = delx * x1;
                                delw2 = delx * x2;
                                delw3 = delx * x3;
                                delw4 = delx * x4;
                                delw = delx;

                                w1 += delw1;
                                w2 += delw2;
                                w3 += delw3;
                                w4 += delw4;
                                umb += delw;

                                lb_epocas.Items.Add("Actualizacion (" + i + ")");
                                lb_epocas.Items.Add("DX = " + delx);
                                lb_epocas.Items.Add("DW1 = " + delw1);
                                lb_epocas.Items.Add("DW2 = " + delw2);
                                lb_epocas.Items.Add("DW3 = " + delw3);
                                lb_epocas.Items.Add("DW4 = " + delw4);
                                lb_epocas.Items.Add("DW0 = " + delw);
                                lb_epocas.Items.Add("\n");
                                lb_epocas.Items.Add("Nuevos datos");
                                lb_epocas.Items.Add("W1 = " + w1);
                                lb_epocas.Items.Add("W2 = " + w2);
                                lb_epocas.Items.Add("W3 = " + w3);
                                lb_epocas.Items.Add("W4 = " + w4);
                                lb_epocas.Items.Add("Umbral = " + umb);
                                lb_epocas.Items.Add("\n");
                            }
                        }

                        epoca++;
                    }
                    lb_epocas.Items.Add("Total de epocas necesarias = " + epoca);
                    if (!validacion)
                    {
                        lb_epocas.Items.Add("No se encontro una solucion dentro de 100 epocas");
                    }
                    break;
                case "Setosa-Virginica":
                    Random randSV = new Random();
                    float x1SV, x2SV, x3SV, x4SV, y1SV, y2SV, y3SV, y4SV, delwSV, delw1SV, delw2SV, delw3SV, delw4SV, delxSV, YcalSV, YespSV;
                    float w1SV = (float)Math.Round(randSV.NextDouble(), 2);
                    float w2SV = (float)Math.Round(randSV.NextDouble(), 2);
                    float w3SV = (float)Math.Round(randSV.NextDouble(), 2);
                    float w4SV = (float)Math.Round(randSV.NextDouble(), 2);
                    float umbSV = (float)Math.Round(randSV.NextDouble(), 2);
                    lb_epocas.Items.Add("W1 = " + w1SV);
                    lb_epocas.Items.Add("W2 = " + w2SV);
                    lb_epocas.Items.Add("W3 = " + w3SV);
                    lb_epocas.Items.Add("W4 = " + w4SV);
                    lb_epocas.Items.Add("Umbral = " + umbSV);

                    int epocaSV = 0, maxepocaSV = 5;
                    bool validacionSV = false;

                    while (epocaSV < maxepocaSV)
                    {
                        lb_epocas.Items.Add("Epoca = " + epocaSV);
                        lb_epocas.Items.Add("\n");

                        validacion = true;

                        for (int i = 0; i < 100; i++)
                        {
                            DataGridViewRow row = dataGridView1.Rows[i];
                            x1SV = Convert.ToSingle(row.Cells["LS"].Value);
                            x2SV = Convert.ToSingle(row.Cells["AS"].Value);
                            x3SV = Convert.ToSingle(row.Cells["LP"].Value);
                            x4SV = Convert.ToSingle(row.Cells["AP"].Value);
                            YespSV = Convert.ToSingle(row.Cells["Yesp"].Value);

                            YcalSV = (x1SV * w1SV) + (x2SV * w2SV) + (x3SV * w3SV) + (x4SV * w4SV) + umbSV;

                            if (YcalSV > 0)
                            {
                                YcalSV = 1;
                            }
                            else
                            {
                                YcalSV = -1;
                            }

                            row.Cells["Ycal"].Value = YcalSV;

                            lb_epocas.Items.Add("Cambios en los pesos (" + i + ")");
                            lb_epocas.Items.Add("W1 = " + w1SV);
                            lb_epocas.Items.Add("W2 = " + w2SV);
                            lb_epocas.Items.Add("W3 = " + w3SV);
                            lb_epocas.Items.Add("W4 = " + w4SV);
                            lb_epocas.Items.Add("Umbral = " + umbSV);
                            lb_epocas.Items.Add("Ycal = " + YcalSV);

                            if (YcalSV != YespSV)
                            {
                                validacionSV = false;

                                delxSV = YespSV - YcalSV;
                                delw1SV = delxSV * x1SV;
                                delw2SV = delxSV * x2SV;
                                delw3SV = delxSV * x3SV;
                                delw4SV = delxSV * x4SV;
                                delwSV = delxSV;

                                w1SV += delw1SV;
                                w2SV += delw2SV;
                                w3SV += delw3SV;
                                w4SV += delw4SV;
                                umbSV += delwSV;

                                lb_epocas.Items.Add("Actualizacion (" + i + ")");
                                lb_epocas.Items.Add("DX = " + delxSV);
                                lb_epocas.Items.Add("DW1 = " + delw1SV);
                                lb_epocas.Items.Add("DW2 = " + delw2SV);
                                lb_epocas.Items.Add("DW3 = " + delw3SV);
                                lb_epocas.Items.Add("DW4 = " + delw4SV);
                                lb_epocas.Items.Add("DW0 = " + delwSV);
                                lb_epocas.Items.Add("\n");
                                lb_epocas.Items.Add("Nuevos datos");
                                lb_epocas.Items.Add("W1 = " + w1SV);
                                lb_epocas.Items.Add("W2 = " + w2SV);
                                lb_epocas.Items.Add("W3 = " + w3SV);
                                lb_epocas.Items.Add("W4 = " + w4SV);
                                lb_epocas.Items.Add("Umbral = " + umbSV);
                                lb_epocas.Items.Add("\n");
                            }
                        }

                        epocaSV++;
                    }
                    lb_epocas.Items.Add("Total de epocas necesarias = " + epocaSV);
                    if (!validacionSV)
                    {
                        lb_epocas.Items.Add("No se encontro una solucion dentro de 100 epocas");
                    }
                    break;
                case "Versicolor-Virginica":
                    Random randV = new Random();
                    float x1V, x2V, x3V, x4V, y1V, y2V, y3V, y4V, delwV, delw1V, delw2V, delw3V, delw4V, delxV, YcalV, YespV;
                    float w1V = (float)Math.Round(randV.NextDouble(), 2);
                    float w2V = (float)Math.Round(randV.NextDouble(), 2);
                    float w3V = (float)Math.Round(randV.NextDouble(), 2);
                    float w4V = (float)Math.Round(randV.NextDouble(), 2);
                    float umbV = (float)Math.Round(randV.NextDouble(), 2);
                    lb_epocas.Items.Add("W1 = " + w1V);
                    lb_epocas.Items.Add("W2 = " + w2V);
                    lb_epocas.Items.Add("W3 = " + w3V);
                    lb_epocas.Items.Add("W4 = " + w4V);
                    lb_epocas.Items.Add("Umbral = " + umbV);

                    int epocaV = 0, maxepocaV = 5;
                    bool validacionV = false;

                    while (epocaV < maxepocaV)
                    {
                        lb_epocas.Items.Add("Epoca = " + epocaV);
                        lb_epocas.Items.Add("\n");

                        validacionV = true;

                        for (int i = 0; i < 100; i++)
                        {
                            DataGridViewRow row = dataGridView1.Rows[i];
                            x1V = Convert.ToSingle(row.Cells["LS"].Value);
                            x2V = Convert.ToSingle(row.Cells["AS"].Value);
                            x3V = Convert.ToSingle(row.Cells["LP"].Value);
                            x4V = Convert.ToSingle(row.Cells["AP"].Value);
                            YespV = Convert.ToSingle(row.Cells["Yesp"].Value);

                            YcalV = (x1V * w1V) + (x2V * w2V) + (x3V * w3V) + (x4V * w4V) + umbV;

                            if (YcalV > 0)
                            {
                                YcalV = 1;
                            }
                            else
                            {
                                YcalV = -1;
                            }

                            row.Cells["Ycal"].Value = YcalV;

                            lb_epocas.Items.Add("Cambios en los pesos (" + i + ")");
                            lb_epocas.Items.Add("W1 = " + w1V);
                            lb_epocas.Items.Add("W2 = " + w2V);
                            lb_epocas.Items.Add("W3 = " + w3V);
                            lb_epocas.Items.Add("W4 = " + w4V);
                            lb_epocas.Items.Add("Umbral = " + umbV);
                            lb_epocas.Items.Add("Ycal = " + YcalV);

                            if (YcalV != YespV)
                            {
                                validacionV = false;

                                delxV = YespV - YcalV;
                                delw1V = delxV * x1V;
                                delw2V = delxV * x2V;
                                delw3V = delxV * x3V;
                                delw4V = delxV * x4V;
                                delwV = delxV;

                                w1V += delw1V;
                                w2V += delw2V;
                                w3V += delw3V;
                                w4V += delw4V;
                                umbV += delwV;

                                lb_epocas.Items.Add("Actualizacion (" + i + ")");
                                lb_epocas.Items.Add("DX = " + delxV);
                                lb_epocas.Items.Add("DW1 = " + delw1V);
                                lb_epocas.Items.Add("DW2 = " + delw2V);
                                lb_epocas.Items.Add("DW3 = " + delw3V);
                                lb_epocas.Items.Add("DW4 = " + delw4V);
                                lb_epocas.Items.Add("DW0 = " + delwV);
                                lb_epocas.Items.Add("\n");
                                lb_epocas.Items.Add("Nuevos datos");
                                lb_epocas.Items.Add("W1 = " + w1V);
                                lb_epocas.Items.Add("W2 = " + w2V);
                                lb_epocas.Items.Add("W3 = " + w3V);
                                lb_epocas.Items.Add("W4 = " + w4V);
                                lb_epocas.Items.Add("Umbral = " + umbV);
                                lb_epocas.Items.Add("\n");
                            }
                        }

                        epocaV++;
                    }
                    lb_epocas.Items.Add("Total de epocas necesarias = " + epocaV);
                    if (!validacionV)
                    {
                        lb_epocas.Items.Add("No se encontro una solucion dentro de 100 epocas");
                    }
                    break;
            }    
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.Columns.Clear();
            dataGridView1.Rows.Clear();
            lb_epocas.Items.Clear();
        }
    }
}